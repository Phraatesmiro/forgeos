class Transformer:
    @staticmethod
    def find_transformations(models: list) -> list:
        transformations = []
        if len(models) >= 2:
            if "Quantum Harmonic Oscillator" in models and "Harmonic Oscillator" in models:
                transformations.append({
                    "source": "Quantum Harmonic Oscillator",
                    "target": "Harmonic Oscillator",
                    "condition": "n → ∞",
                    "type": "approximation",
                    "description": "Correspondence principle"
                })
            if "Lotka-Volterra" in models and "SIR Model" in models:
                transformations.append({
                    "source": "Lotka-Volterra",
                    "target": "SIR Model",
                    "condition": "population dynamics → epidemic spread",
                    "type": "structural",
                    "description": "Both are dynamical systems"
                })
        return transformations
    
    @staticmethod
    def find_path(source: str, target: str) -> list:
        if source == target:
            return []
        return [{"source": source, "target": target, "type": "direct"}]
