class ContextManager:
    def __init__(self):
        self.current_page = "prompt"
        self.current_models = []
        self.session_history = []
        self.user_preferences = {}
    
    def set_page(self, page: str):
        self.current_page = page
    
    def add_model(self, model: str):
        if model not in self.current_models:
            self.current_models.append(model)
    
    def add_to_history(self, action: str):
        self.session_history.append(action)
    
    @staticmethod
    def find_models(query: str):
        models = []
        if "quantum" in query.lower() or "physics" in query.lower():
            models.append("Quantum Harmonic Oscillator")
        if "biology" in query.lower() or "population" in query.lower():
            models.append("Lotka-Volterra")
        if "economy" in query.lower() or "market" in query.lower():
            models.append("Black-Scholes")
        return models
