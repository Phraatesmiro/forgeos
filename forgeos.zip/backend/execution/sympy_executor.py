import sympy as sp
import numpy as np

class SympyExecutor:
    @staticmethod
    def execute(model: str, parameters: dict, domain: dict = None) -> dict:
        results = {}
        x = sp.Symbol('x')
        expr_str = parameters.get("expression", "x**2")
        try:
            expr = sp.sympify(expr_str)
            results["expression"] = str(expr)
            subs = {}
            for key, value in parameters.items():
                if key != "expression" and key != "domain":
                    subs[sp.Symbol(key)] = float(value)
            expr_subs = expr.subs(subs)
            results["substituted"] = str(expr_subs)
            if domain:
                x_vals = np.linspace(domain.get("x_min", -10), domain.get("x_max", 10), domain.get("num_points", 100))
                func = sp.lambdify(x, expr_subs, modules=['numpy'])
                results["values"] = func(x_vals).tolist()
                results["domain"] = x_vals.tolist()
            results["derivative"] = str(sp.diff(expr, x))
            results["integral"] = str(sp.integrate(expr, x))
        except Exception as e:
            results["error"] = str(e)
        return results
