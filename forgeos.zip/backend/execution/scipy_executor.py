import numpy as np
from scipy.integrate import odeint

class ScipyExecutor:
    @staticmethod
    def execute(model: str, parameters: dict, domain: dict = None) -> dict:
        results = {}
        try:
            if model == "lotka_volterra":
                results = ScipyExecutor._lotka_volterra(parameters, domain)
            elif model == "sir":
                results = ScipyExecutor._sir(parameters, domain)
            else:
                results["message"] = f"Simulation for {model} not implemented yet."
                results["parameters"] = parameters
        except Exception as e:
            results["error"] = str(e)
        return results
    
    @staticmethod
    def _lotka_volterra(params: dict, domain: dict) -> dict:
        def system(y, t, a, b, c, d):
            x, y_pop = y
            dxdt = a*x - b*x*y_pop
            dydt = -c*y_pop + d*x*y_pop
            return [dxdt, dydt]
        a = params.get("a", 1.0)
        b = params.get("b", 0.5)
        c = params.get("c", 0.5)
        d = params.get("d", 0.5)
        x0 = params.get("x0", 1.0)
        y0 = params.get("y0", 1.0)
        t = np.linspace(0, 20, 500)
        sol = odeint(system, [x0, y0], t, args=(a, b, c, d))
        return {"time": t.tolist(), "prey": sol[:, 0].tolist(), "predator": sol[:, 1].tolist()}
    
    @staticmethod
    def _sir(params: dict, domain: dict) -> dict:
        def system(y, t, beta, gamma):
            S, I, R = y
            dSdt = -beta*S*I
            dIdt = beta*S*I - gamma*I
            dRdt = gamma*I
            return [dSdt, dIdt, dRdt]
        beta = params.get("beta", 0.3)
        gamma = params.get("gamma", 0.1)
        S0 = params.get("S0", 0.99)
        I0 = params.get("I0", 0.01)
        R0 = params.get("R0", 0.0)
        t = np.linspace(0, 100, 500)
        sol = odeint(system, [S0, I0, R0], t, args=(beta, gamma))
        return {"time": t.tolist(), "S": sol[:, 0].tolist(), "I": sol[:, 1].tolist(), "R": sol[:, 2].tolist(), "R0": beta/gamma}
