from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class ModelBase(BaseModel):
    name: str
    domain: str
    description: Optional[str] = None
    input: List[str] = []
    output: List[str] = []

class ModelCreate(ModelBase):
    validation_status: str = "unverified"

class ModelResponse(ModelBase):
    id: str
    validation_status: str

class TransformationBase(BaseModel):
    source: str
    target: str
    condition: Optional[str] = None
    type: str = "connection"

class TransformationResponse(TransformationBase):
    id: str

class PromptRequest(BaseModel):
    query: str
    context: Optional[Dict[str, Any]] = None

class PromptResponse(BaseModel):
    answer: str
    models: List[str] = []
    transformations: List[str] = []

class SimulateRequest(BaseModel):
    model: str
    parameters: Dict[str, Any]
    domain: Optional[Dict[str, Any]] = None

class SimulateResponse(BaseModel):
    result: Dict[str, Any]
    model: str
    status: str = "success"
