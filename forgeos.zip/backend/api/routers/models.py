from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import yaml

router = APIRouter(prefix="/api/models", tags=["models"])

class ModelResponse(BaseModel):
    id: str
    name: str
    domain: str
    description: Optional[str] = None
    input: List[str] = []
    output: List[str] = []
    validation_status: str = "unverified"

@router.get("/", response_model=List[ModelResponse])
async def list_models():
    try:
        with open("data/models.yaml", "r") as f:
            data = yaml.safe_load(f)
        models = data.get("models", [])
        return [
            ModelResponse(
                id=m.get("name", "").lower().replace(" ", "_"),
                name=m.get("name", ""),
                domain=m.get("domain", "unknown"),
                description=m.get("description", ""),
                input=m.get("input", []),
                output=m.get("output", []),
                validation_status=m.get("validation_status", "unverified")
            )
            for m in models
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{model_id}")
async def get_model(model_id: str):
    try:
        with open("data/models.yaml", "r") as f:
            data = yaml.safe_load(f)
        for m in data.get("models", []):
            if m.get("name", "").lower().replace(" ", "_") == model_id:
                return m
        raise HTTPException(status_code=404, detail="Model not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
