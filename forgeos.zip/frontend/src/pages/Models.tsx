import { useState, useEffect } from 'react'
import axios from 'axios'

interface Model {
  id: string
  name: string
  domain: string
  description: string
  input: string[]
  output: string[]
  validation_status: string
}

export function Models() {
  const [models, setModels] = useState<Model[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    axios.get('http://localhost:8000/api/models')
      .then((res) => {
        setModels(res.data)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const filtered = models.filter((m) =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.domain.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="bg-white/60 backdrop-blur-md rounded-3xl p-5 border border-white/30 shadow-sm">
      <div className="text-base font-semibold text-[#1a1a2e] mb-3">📚 Modeller</div>

      <div className="flex gap-2 mb-3">
        <input
          className="flex-1 bg-white/30 border border-white/20 rounded-xl px-4 py-2.5 text-sm text-[#1a1a2e] outline-none focus:border-white/40"
          placeholder="🔍 Sök modell..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <span className="px-4 py-2.5 bg-white/20 rounded-xl text-xs text-[#6a6a8a] border border-white/10">Filter ▼</span>
      </div>

      {loading ? (
        <div className="text-center text-[#6a6a8a] py-8">Laddar modeller...</div>
      ) : (
        filtered.slice(0, 10).map((model) => (
          <div key={model.id} className="flex justify-between items-center py-3 border-b border-black/5 last:border-0">
            <div>
              <span className="font-medium text-[#1a1a2e]">{model.name}</span>
              {model.validation_status === 'verified_standard' && (
                <span className="text-[10px] font-medium text-green-600 bg-green-50/50 px-2 py-0.5 rounded-full ml-2 border border-green-200/30">Verifierad</span>
              )}
              <div className="text-xs text-[#6a6a8a] mt-0.5">{model.domain} · {model.input.length} ingångar</div>
            </div>
            <span className="text-xs px-3 py-1 bg-white/30 rounded-lg text-[#4a4a6a]">Visa</span>
          </div>
        ))
      )}
    </div>
  )
}
